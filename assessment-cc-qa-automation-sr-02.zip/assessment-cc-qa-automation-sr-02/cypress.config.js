import { defineConfig } from 'cypress'

export default defineConfig({
    e2e: {
        setupNodeEvents(on, config) {
          //node events here
        },
        specPattern: 'cypress/e2e/*.js',
  },
    component: {
        // path to compoment test (unit test)
  }
})