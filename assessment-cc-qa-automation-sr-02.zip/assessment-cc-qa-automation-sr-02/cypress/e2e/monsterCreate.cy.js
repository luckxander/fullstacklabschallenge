/// <reference types="cypress" />

import MonsterImagePage from '/cypress/elements/pages/MonsterImagePage';
import MonsterNamePage from '/cypress/elements/pages/MonsterNamePage';
import MonsterHpPage from '/cypress/elements/pages/MonsterHpPage';
import MonsterAttackPage from '/cypress/elements/pages/MonsterAttackPage';
import MonsterDefensePage from '/cypress/elements/pages/MonsterDefensePage';
import MonsterSpeedPage from '/cypress/elements/pages/MonsterSpeedPage';
import MonsterButtonPage from '/cypress/elements/pages/MonsterButtonPage';


const monsterImagePage = new MonsterImagePage();
const monsterNamePage = new MonsterNamePage();
const monsterHpPage = new MonsterHpPage();
const monsterAttackPage = new MonsterAttackPage();
const monsterDefensePage = new MonsterDefensePage();
const monsterSpeedPage = new MonsterSpeedPage();
const monsterButtonPage = new MonsterButtonPage();


describe('Creating, validating and deleting a Monster', () => {

    it('Create an Unicor Monster, validate and delete it', () => {
       
        cy.visit('http://localhost:3000/');
       
       monsterImagePage.selectMonsterImage('monster-1');
       monsterNamePage.addMonsterName('Unicorn');
       monsterHpPage.addHp(25);
       monsterAttackPage.addAttack(50);
       monsterDefensePage.addDefense(15);
       monsterSpeedPage.addSpeed(90);
       monsterButtonPage.clickCreateMonsterButton();
       monsterNamePage.validateMonsterCreated('Unicorn');
       monsterButtonPage.clickDeleteMonsterButton();
       monsterNamePage.validateMonsterDeleted('There are no monsters');

    })
})