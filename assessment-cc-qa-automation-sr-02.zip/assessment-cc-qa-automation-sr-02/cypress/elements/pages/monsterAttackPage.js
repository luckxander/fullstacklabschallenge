class MonsterAttackPage{
    addAttack(attackValue){

      cy.get('[data-testid="attack-value"]').type(attackValue)

    }

}

export default MonsterAttackPage