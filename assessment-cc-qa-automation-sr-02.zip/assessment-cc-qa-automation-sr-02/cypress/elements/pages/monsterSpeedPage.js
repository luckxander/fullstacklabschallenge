class MonsterSpeedPage{

    addSpeed(speedValue){
        cy.get('[data-testid="speed-value"]').type(90);
    }

}

export default MonsterSpeedPage