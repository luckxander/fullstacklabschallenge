class MonsterImagePage{

    selectMonsterImage(image){
        
        cy.get('[data-testid=' + image +']').click();

    }

}

export default MonsterImagePage