class MonsterDefensePage{

   addDefense(defenseValue){

    cy.get('[data-testid="defense-value"]').type(defenseValue);

   }

}

export default MonsterDefensePage