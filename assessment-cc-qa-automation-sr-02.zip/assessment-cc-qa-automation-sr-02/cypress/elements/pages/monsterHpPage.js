class MonsterHpPage{

    addHp(hpValue){
        cy.get('[data-testid="hp-value"]').type(hpValue);
    }

}

export default MonsterHpPage