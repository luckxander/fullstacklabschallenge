class MonsterNamePage {

   addMonsterName(name){
    cy.get('[data-testid="monster-name"]').type(name);
   }

   validateMonsterCreated(givenName){
     cy.get('[data-testid="card-monster-name"]').scrollIntoView().should('have.text', givenName);
   }


   validateMonsterDeleted(deleted){
    cy.get('[data-testid="dynamic-title"]').should('have.text', deleted);
  }

}

export default MonsterNamePage