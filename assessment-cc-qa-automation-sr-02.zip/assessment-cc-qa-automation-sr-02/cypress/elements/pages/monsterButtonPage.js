class MonsterButtonPage{
    
    elements = {

        buttons: {

            createMonster:() => cy.get('[data-testid="btn-create-monster"]'),
            deleteMonster:() => cy.get('[data-testid="btn-delete"]'),
        }
    }

    clickCreateMonsterButton(){
        this.elements.buttons.createMonster().click();
    }

    clickDeleteMonsterButton(){
        this.elements.buttons.deleteMonster().click();
    }


}

export default MonsterButtonPage